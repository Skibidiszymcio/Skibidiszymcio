#include <iostream>

using namespace std;

void zmiana(int tempC, char skala) {
    if (skala == 'F' || skala == 'f' ) {
        int tempF = (tempC * 9.0 / 5.0) + 32;
        cout << "Temperatura w Fahrenheitach: " << tempF << " F" << endl;
    }
    else if (skala == 'K' || skala == 'k') {
        int tempK = tempC + 273.15;
        cout << "Temperatura w Kelwinach: " << tempK << " K" << endl;
    }
    else {
        cout << "Zla skala" << endl;
    }
}

int main() {
    int tempC;
    char skala;

    cout << "Podaj temperature w Celsjuszach: ";
    cin >> tempC;

    cout << "Podaj skale F = Fahrenheit K = Kelwina): ";
    cin >> skala;

    zmiana(tempC, skala);
}


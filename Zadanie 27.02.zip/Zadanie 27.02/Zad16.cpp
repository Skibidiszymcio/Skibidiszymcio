#include <iostream>

using namespace std;

int sumaPrzedzial(int a, int b) {
    int suma ;

    if (a <= b) {
        for (int i = a; i <= b; i++) {
            suma += i;
        }
    } else {
        for (int i = b; i <= a; i++) {
            suma += i;
        }
    }
    return suma;
}

int main() {
    int a, b;

    cout << "Podaj dwie liczby: ";
    cin >> a >> b;

    int wynik = sumaPrzedzial(a, b);
    cout << "Suma liczb w przedziale: " << wynik << endl;
}


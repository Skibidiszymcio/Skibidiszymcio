#include <iostream>

using namespace std;

void bezwzgledna(int liczba) {
		if (liczba < 0) 
        liczba = -liczba;
        cout<<"Liczba to: "<<liczba;
}

int main() {
    int liczba;
    cout << "Podaj liczbe: ";
    cin >> liczba;

    bezwzgledna(liczba);

    return 0;
}

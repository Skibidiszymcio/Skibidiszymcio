#include <iostream>

using namespace std;

void dlug(int kwota, int miesiace) {
    
    for (int i = 1; i <= miesiace; i++) {
        kwota = kwota * 1.05;
    }
    cout << "Po " << miesiace << " miesiacach dlug wynosi: " << kwota << " zl" << endl;
}

int main() {
    int kwota;
    int miesiace;

    cout << "Podaj kwote pozyczki: ";
    cin >> kwota;

    cout << "Podaj liczbe miesiecy: ";
    cin >> miesiace;

    dlug(kwota, miesiace);

}


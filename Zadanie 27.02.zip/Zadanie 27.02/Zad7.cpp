#include <iostream>

using namespace std;

void kombinacje() {
    char litery[3] = {'a', 'b', 'c'};


    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            for (int k = 0; k < 3; k++) {
                cout << litery[k] << litery[j] << litery[i] << endl;
            }
        }
    }
}

int main() {
    kombinacje();  
}


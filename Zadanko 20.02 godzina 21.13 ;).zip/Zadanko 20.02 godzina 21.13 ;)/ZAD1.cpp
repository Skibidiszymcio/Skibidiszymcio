#include <iostream>
using namespace std;

string dzienTyg(int dzien){

	 if(dzien == 1)
	 return "Niedziela";
	
	else if(dzien == 2)
	 return "Poniedzialek";	
	else if(dzien == 3)
	 return "Wtorek";	
	else if(dzien == 4)
	 return "Sroda";	
	else if(dzien == 5)
	 return "Czwartek";
	if(dzien == 6)
	 return "Piatek";	
	else
	 return "Sobota";	
	
}

main() {
	
	cout<<dzienTyg(2);
	
}

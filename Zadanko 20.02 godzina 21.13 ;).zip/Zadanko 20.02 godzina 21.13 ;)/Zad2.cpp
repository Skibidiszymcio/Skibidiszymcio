#include <iostream>
using namespace std;

float poleTrapezu(float a,float b,float h){


	return ((a + b)*h)/2;
	
}


main() {

	int a,b,h;

	cin>>a;
	cin>>b;
	cin>>h;
	
	float pole = poleTrapezu(a,b,h);
	cout << "Pole trapezu wynosi: " << pole << endl;

}

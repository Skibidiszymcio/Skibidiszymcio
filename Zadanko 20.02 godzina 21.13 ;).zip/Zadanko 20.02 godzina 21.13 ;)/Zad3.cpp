#include <iostream>

using namespace std;

float najmniejsza(float a, float b, float c) {
    float minVal = a; 

    if (b < minVal) {
        minVal = b; 
    }
    if (c < minVal) {
        minVal = c; 
    }

    return minVal; 
}

int main() {
    float x, y, z;

    cout << "Podaj trzy liczby: ";
    cin >> x >> y >> z;

    cout << "Najmniejsza wartosc: " << najmniejsza(x, y, z) << endl;

    return 0;
}

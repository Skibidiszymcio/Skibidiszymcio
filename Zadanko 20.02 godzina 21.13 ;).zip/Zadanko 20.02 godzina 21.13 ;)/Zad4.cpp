#include <iostream>

using namespace std;

void kwadrat(char litera, int rozmiar) {
    for (int i = 0; i < rozmiar; i++) {
        for (int j = 0; j < rozmiar; j++) {
            cout << litera; 
        }
        cout << endl; 
    }
}

int main() {
    char litera;
    int rozmiar;

    cout << "Podaj litere: ";
    cin >> litera;
    cout << "Podaj rozmiar kwadratu: ";
    cin >> rozmiar;

    kwadrat(litera, rozmiar);

    return 0;
}
